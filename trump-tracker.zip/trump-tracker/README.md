# 🇺🇸 TRUMP MENTION TRACKER 🦅

> How many times did major TV news networks say "TRUMP"?
> Live closed-caption data via GDELT + Internet Archive.

---

## 🚀 DEPLOY IN 5 MINUTES (No coding required)

### Step 1 — Install Node.js (if you don't have it)
Download from: https://nodejs.org  (click the big green "LTS" button)

### Step 2 — Build the site
Open Terminal (Mac) or Command Prompt (Windows), then:

```bash
cd trump-tracker        # go into this folder
npm install             # downloads dependencies (~30 seconds)
npm run build           # builds the site into /dist folder
```

### Step 3 — Deploy to Netlify (FREE, takes 60 seconds)

1. Go to https://netlify.com and sign up (free)
2. From your Netlify dashboard, click **"Add new site"** → **"Deploy manually"**
3. Drag and drop the **`dist`** folder onto the upload area
4. 🎉 YOUR SITE IS LIVE — Netlify gives you a URL instantly

### Step 4 — Set up the API proxy (makes real data work)

The site needs one Netlify Function to proxy the GDELT API.
When you drag-drop the `dist` folder, functions aren't included.

**For full functionality, use Netlify CLI instead:**

```bash
npm install -g netlify-cli     # install Netlify CLI
netlify login                  # opens browser to log in
netlify deploy --prod          # deploys everything including functions
```

That's it. Your site will have a real `.netlify.app` URL and live data.

---

## Custom Domain (optional)
In Netlify dashboard → Site settings → Domain management → Add custom domain.
Costs ~$15/yr from Namecheap or Google Domains.

---

## Data Source
- **GDELT Project TV 2.0 API** — https://gdeltproject.org
- **Internet Archive TV News** — https://archive.org/details/tv
- Metric: % of 15-second closed-caption clips containing "trump" per network
- Updates: data is available within ~24 hours of broadcast

---

## File Structure
```
trump-tracker/
├── netlify.toml              ← Netlify build config + proxy routing
├── netlify/functions/
│   └── gdelt.js              ← Serverless proxy (bypasses CORS)
├── src/
│   ├── main.jsx              ← React entry point
│   └── App.jsx               ← Main app (all the freedom)
├── index.html
├── package.json
└── vite.config.js
```

---

🇺🇸 *Land of the Free. Home of the Data.* 🦅
